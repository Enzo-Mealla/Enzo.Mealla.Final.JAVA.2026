
package proyectoalmacen;


public class DatoInvalidoException extends Exception {
    
    public DatoInvalidoException(String mensaje) {
        super(mensaje);
    }
    
}
